package com.hudplus.hud;

import com.hudplus.config.HudConfig;
import com.hudplus.waypoint.Waypoint;
import com.hudplus.waypoint.WaypointManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.List;

public class HudRenderer {

    private static final int PADDING = 4;
    private static final int LINE_HEIGHT = 10;
    private static final int BG_COLOR = 0x88000000;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private static final int TEXT_YELLOW = 0xFFFFFF55;
    private static final int TEXT_AQUA = 0xFF55FFFF;
    private static final int TEXT_GREEN = 0xFF55FF55;
    private static final int TEXT_GOLD = 0xFFFFAA00;

    public static void render(DrawContext ctx, float tickDelta, MinecraftClient client) {
        HudConfig cfg = HudConfig.get();
        if (!cfg.hudVisible) return;
        if (client.player == null || client.world == null) return;

        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        TextRenderer font = client.textRenderer;

        int screenW = client.getWindow().getScaledWidth();
        int x = PADDING;
        int y = PADDING;

        // ─── TOP LEFT PANEL ───
        int panelX = x;
        int panelY = y;
        int panelW = 120;
        int lines = countEnabledLines(cfg);
        drawPanel(ctx, panelX - 2, panelY - 2, panelW, lines * LINE_HEIGHT + 4);

        if (cfg.showDays) {
            long day = world.getTimeOfDay() / 24000L;
            ctx.drawTextWithShadow(font, "§e☀ Day: §f" + day, x, y, TEXT_WHITE);
            y += LINE_HEIGHT;
        }

        if (cfg.showCoords) {
            BlockPos pos = player.getBlockPos();
            String coordStr = String.format("§bX:§f%d §bY:§f%d §bZ:§f%d", pos.getX(), pos.getY(), pos.getZ());
            ctx.drawTextWithShadow(font, coordStr, x, y, TEXT_WHITE);
            y += LINE_HEIGHT;
        }

        if (cfg.showFps) {
            int fps = client.getCurrentFps();
            String fpsColor = fps >= 60 ? "§a" : fps >= 30 ? "§e" : "§c";
            ctx.drawTextWithShadow(font, fpsColor + "FPS: §f" + fps, x, y, TEXT_WHITE);
            y += LINE_HEIGHT;
        }

        if (cfg.showClock) {
            long ticks = world.getTimeOfDay() % 24000L;
            // Minecraft day starts at 6:00. Tick 0 = 6:00
            long totalMinutes = (ticks * 1440L / 24000L + 360L) % 1440L;
            int hours = (int)(totalMinutes / 60);
            int mins = (int)(totalMinutes % 60);
            ctx.drawTextWithShadow(font, String.format("§d⏰ %02d:%02d", hours, mins), x, y, TEXT_WHITE);
            y += LINE_HEIGHT;
        }

        if (cfg.showCompass) {
            String compass = getCompassDirection(player.getYaw(tickDelta));
            ctx.drawTextWithShadow(font, "§6➤ " + compass, x, y, TEXT_WHITE);
            y += LINE_HEIGHT;
        }

        // ─── WAYPOINT LIST (top right) ───
        if (cfg.showWaypointLabels) {
            renderWaypointList(ctx, font, client, screenW, player, world);
        }
    }

    private static void renderWaypointList(DrawContext ctx, TextRenderer font,
            MinecraftClient client, int screenW, ClientPlayerEntity player, ClientWorld world) {
        List<Waypoint> wps = WaypointManager.getInstance().getWaypoints();
        if (wps.isEmpty()) return;

        String currentDim = getDimensionName(world);
        BlockPos playerPos = player.getBlockPos();

        int listW = 160;
        int listX = screenW - listW - PADDING;
        int listY = PADDING;

        // count visible waypoints in this dimension
        long count = wps.stream().filter(w -> w.isVisible() && w.getDimension().equals(currentDim)).count();
        if (count == 0) return;

        drawPanel(ctx, listX - 2, listY - 2, listW, (int)(count * LINE_HEIGHT) + 4);

        for (Waypoint wp : wps) {
            if (!wp.isVisible()) continue;
            if (!wp.getDimension().equals(currentDim)) continue;

            int dist = wp.getDistance(playerPos);
            float[] rgb = wp.getColorRGB();
            int argb = 0xFF000000
                | ((int)(rgb[0] * 255) << 16)
                | ((int)(rgb[1] * 255) << 8)
                | (int)(rgb[2] * 255);

            String label = String.format("§f%s §7| §f%d,%d,%d §8(%dm)",
                wp.getName(),
                wp.getPos().getX(), wp.getPos().getY(), wp.getPos().getZ(),
                dist);

            ctx.drawTextWithShadow(font, "● ", listX, listY, argb);
            ctx.drawTextWithShadow(font, label, listX + 8, listY, TEXT_WHITE);
            listY += LINE_HEIGHT;
        }
    }

    /**
     * Render in-world waypoint beacons (called from WorldRenderEvent)
     */
    public static void renderWorldWaypoints(net.minecraft.client.render.WorldRenderContext context) {
        HudConfig cfg = HudConfig.get();
        if (!cfg.hudVisible || !cfg.showWaypointBeacons) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        String currentDim = getDimensionName(client.world);
        List<Waypoint> wps = WaypointManager.getInstance().getWaypoints();

        net.minecraft.client.render.Camera camera = context.camera();
        net.minecraft.entity.Entity camEntity = camera.getFocusedEntity();
        if (camEntity == null) return;

        double camX = camera.getPos().x;
        double camY = camera.getPos().y;
        double camZ = camera.getPos().z;

        net.minecraft.client.render.VertexConsumerProvider.Immediate immediate =
            client.getBufferBuilders().getEntityVertexConsumers();

        for (Waypoint wp : wps) {
            if (!wp.isVisible()) continue;
            if (!wp.getDimension().equals(currentDim)) continue;

            BlockPos pos = wp.getPos();
            double dx = pos.getX() + 0.5 - camX;
            double dy = pos.getY() + 0.5 - camY;
            double dz = pos.getZ() + 0.5 - camZ;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

            // Draw beacon line from waypoint going up
            float[] rgb = wp.getColorRGB();
            net.minecraft.client.render.RenderLayer layer =
                net.minecraft.client.render.RenderLayer.getDebugLineStrip(2.0);

            net.minecraft.client.util.math.MatrixStack matrices = context.matrixStack();
            matrices.push();
            matrices.translate(dx, dy, dz);

            net.minecraft.client.render.VertexConsumer vc = immediate.getBuffer(layer);

            org.joml.Matrix4f matrix = matrices.peek().getPositionMatrix();
            // Draw vertical beacon line
            for (float t = 0; t <= 64; t += 1f) {
                vc.vertex(matrix, 0f, t, 0f)
                  .color(rgb[0], rgb[1], rgb[2], Math.max(0f, 1f - (float)dist / 512f))
                  .normal(0, 1, 0);
            }

            immediate.draw(layer);
            matrices.pop();
        }
    }

    private static int countEnabledLines(HudConfig cfg) {
        int n = 0;
        if (cfg.showDays) n++;
        if (cfg.showCoords) n++;
        if (cfg.showFps) n++;
        if (cfg.showClock) n++;
        if (cfg.showCompass) n++;
        return n;
    }

    private static void drawPanel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, BG_COLOR);
    }

    private static String getCompassDirection(float yaw) {
        yaw = ((yaw % 360) + 360) % 360;
        if (yaw < 22.5f || yaw >= 337.5f) return "§cS §7| N | E | W";
        if (yaw < 67.5f) return "§cSW §7| N | E | ...";
        if (yaw < 112.5f) return "§cW §7| N | S | E";
        if (yaw < 157.5f) return "§cNW";
        if (yaw < 202.5f) return "§cN §7| S | E | W";
        if (yaw < 247.5f) return "§cNE";
        if (yaw < 292.5f) return "§cE §7| N | S | W";
        return "§cSE";
    }

    private static String getCompassSimple(float yaw) {
        yaw = ((yaw % 360) + 360) % 360;
        String[] dirs = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        return dirs[Math.round(yaw / 45f) % 8];
    }

    public static String getDimensionName(ClientWorld world) {
        String key = world.getRegistryKey().getValue().toString();
        if (key.contains("nether")) return "nether";
        if (key.contains("end")) return "end";
        return "overworld";
    }
}

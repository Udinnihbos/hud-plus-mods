package com.hudplus.config;

import com.google.gson.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;

public class HudConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("HudPlus/Config");
    private static HudConfig INSTANCE;
    private final Path file = Paths.get("config", "hudplus_config.json");

    public boolean showCoords = true;
    public boolean showFps = true;
    public boolean showClock = true;
    public boolean showCompass = true;
    public boolean showDays = true;
    public boolean showWaypointLabels = true;
    public boolean showWaypointBeacons = true;
    public boolean hudVisible = true;

    public static HudConfig get() {
        if (INSTANCE == null) {
            INSTANCE = new HudConfig();
            INSTANCE.load();
        }
        return INSTANCE;
    }

    public void save() {
        try {
            Files.createDirectories(file.getParent());
            JsonObject obj = new JsonObject();
            obj.addProperty("showCoords", showCoords);
            obj.addProperty("showFps", showFps);
            obj.addProperty("showClock", showClock);
            obj.addProperty("showCompass", showCompass);
            obj.addProperty("showDays", showDays);
            obj.addProperty("showWaypointLabels", showWaypointLabels);
            obj.addProperty("showWaypointBeacons", showWaypointBeacons);
            obj.addProperty("hudVisible", hudVisible);
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(obj));
        } catch (IOException e) {
            LOGGER.error("Failed to save config", e);
        }
    }

    public void load() {
        if (!Files.exists(file)) return;
        try {
            JsonObject obj = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (obj.has("showCoords")) showCoords = obj.get("showCoords").getAsBoolean();
            if (obj.has("showFps")) showFps = obj.get("showFps").getAsBoolean();
            if (obj.has("showClock")) showClock = obj.get("showClock").getAsBoolean();
            if (obj.has("showCompass")) showCompass = obj.get("showCompass").getAsBoolean();
            if (obj.has("showDays")) showDays = obj.get("showDays").getAsBoolean();
            if (obj.has("showWaypointLabels")) showWaypointLabels = obj.get("showWaypointLabels").getAsBoolean();
            if (obj.has("showWaypointBeacons")) showWaypointBeacons = obj.get("showWaypointBeacons").getAsBoolean();
            if (obj.has("hudVisible")) hudVisible = obj.get("hudVisible").getAsBoolean();
        } catch (Exception e) {
            LOGGER.error("Failed to load config", e);
        }
    }
}

package com.hudplus.mixin;

import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    // Reserved for future render hooks if needed
    // Currently HUD uses fabric events instead
}
